function testRLR(  )

lambda = [0,0.5,1,1.5,2];
Data = importdata('HW3-wine.mat');

trainingFeature = [ones(size(Data.X.train,1),1) , Data.X.train];
y = Data.y.train;

developingFeature = [ones(size(Data.X.dev,1),1) , Data.X.dev];
testingFeature = [ones(size(Data.X.test,1),1) , Data.X.test];

featureSize = size(trainingFeature,2);
I = eye(featureSize);
I(1,1) = 0;

for i = 1:size(lambda,2)
    W = (lambda(i) * I + trainingFeature' * trainingFeature)\(trainingFeature' * y);
    
    fprintf('lambda %f \n', lambda(i) );
    fprintf('training error %f \n', norm(trainingFeature * W - Data.y.train)^2 / size(trainingFeature,1) );
    fprintf('developing error %f \n', norm(developingFeature * W - Data.y.dev)^2 / size(developingFeature,1) );
    fprintf('testing error %f \n', norm(testingFeature * W - Data.y.test)^2 / size(testingFeature,1) );
end

end

