function testBLR_2()

alpha = [50,50,20,10,10,30,30];
beta = [10,20,20,50,500,50,500];

Data = importdata('HW3-wine.mat');
trainingX = [Data.X.train; Data.X.dev];
trainingY = [Data.y.train; Data.y.dev];

testingX = Data.X.test;
testingY = Data.y.test;

meanFeature = mean(trainingX);
meanY = mean(trainingY);

trainingX = trainingX - repmat(meanFeature,size(trainingX,1),1);
trainingY = trainingY - repmat(meanY,size(trainingY,1),1);
testingX = testingX - repmat(meanFeature,size(testingX,1),1);
testingY = testingY - repmat(meanY,size(testingY,1),1);

for i = 1:size(alpha,2)
    fprintf('Inital Alpha %d Inital Beta % d \n', alpha(i), beta(i) );
    
    [empBayesAlpha,empBayesBeta] = estimateAlphaBetaViaEmpiricalBayes(trainingX, trainingY, alpha(i), beta(i));
    [mu, Sigma] = computePosterior(trainingX,trainingY,empBayesBeta,empBayesAlpha);
    
    fprintf('Estimated Alpha %f Estimated Beta % f \n', empBayesAlpha, empBayesBeta );
    fprintf('Training error %f \n', norm(trainingX * mu - trainingY).^2 /size(trainingX,1) );
    fprintf('Testing error %f \n\n', norm(testingX * mu - testingY).^2/size(testingX,1) );
end


end

function [alpha, beta]=estimateAlphaBetaViaEmpiricalBayes(X, T, givenAlpha, givenBeta)
    %% automatically determine alpha, beta
    N = size(X,1);
    alpha = givenAlpha;  % initial value
    beta = givenBeta;
    
    XX = X'*X;
    for iter = 1:10,
        [mu,~] = computePosterior(X,T,beta,alpha);        
        % figure out lambda
        [~, E] = eig(beta*XX);
        E = diag(E);
        gamma = sum( E ./ (E+alpha));
        % reestimate alpha, beta
        alpha = gamma / (mu'*mu);
        beta = (N - gamma)/sum( (T - X*mu).^2);
    end
end

function [mu, Sigma]=computePosterior(X,T,beta,alpha)
    Sigma = inv(alpha*eye(size(X'*X,2)) + beta*(X'*X));
    mu = beta*Sigma*X'*T;
end